<?php

const Config = [
    'Admin'      => [277826937,5570475400],
    'AppInfo'    => ['Api_Id'=> '11567492','Api_Hash'=> '9b857b5f837f6d7f6d6d1ecfb46cfe57'],
    'Database'   => ['User'=>'tadhihsu_resid','Name'=>'tadhihsu_resid','Password'=>'tadhihsu_resid']
];
